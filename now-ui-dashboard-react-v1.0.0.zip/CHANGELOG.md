## [1.0.0] 2017-02-21
### Original Release
- Added Reactstrap as base framework
- Added design from Now Ui Dashboard by Creative Tim
